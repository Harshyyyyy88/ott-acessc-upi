"use client"

import OTTAccess from "../ott-access"

export default function Page() {
  return (
    <main>
      <OTTAccess />
    </main>
  )
}
