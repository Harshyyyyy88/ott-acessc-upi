"use client"

import { useState } from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Slider } from "@/components/ui/slider"
import { NetworkIcon as Netflix, PlusCircle, PlayCircle } from "lucide-react"

export default function OTTAccess() {
  const [selectedPlatform, setSelectedPlatform] = useState("Netflix")
  const [hours, setHours] = useState(1)
  const [price, setPrice] = useState(15)
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const platformRates = {
    Netflix: 15,
    Prime: 10,
    Disney: 12,
  }

  const platformIcons = {
    Netflix: <Netflix className="h-6 w-6 text-red-600" />,
    Prime: <PlusCircle className="h-6 w-6 text-blue-500" />,
    Disney: <PlayCircle className="h-6 w-6 text-purple-600" />,
  }

  const handlePlatformChange = (platform) => {
    setSelectedPlatform(platform)
    setPrice(platformRates[platform] * hours)
  }

  const handleHourChange = (e) => {
    const val = Number(e.target.value)
    if (val >= 1 && val <= 6) {
      setHours(val)
      setPrice(platformRates[selectedPlatform] * val)
    }
  }

  const handleSliderChange = (value) => {
    const val = value[0]
    setHours(val)
    setPrice(platformRates[selectedPlatform] * val)
  }

  const handlePayment = () => {
    setIsDialogOpen(true)
  }

  return (
    <div className="max-w-md mx-auto p-4 space-y-6">
      <Card
        className="border-t-4"
        style={{
          borderTopColor:
            selectedPlatform === "Netflix" ? "#E50914" : selectedPlatform === "Prime" ? "#00A8E1" : "#0063E5",
        }}
      >
        <CardHeader className="pb-2">
          <CardTitle className="text-2xl font-bold text-center flex items-center justify-center gap-2">
            {platformIcons[selectedPlatform]} OTT Access - Pay Per Hour
          </CardTitle>
        </CardHeader>

        <CardContent className="p-6 space-y-6">
          <Tabs defaultValue="Netflix" className="w-full">
            <TabsList className="grid grid-cols-3 gap-2">
              {Object.keys(platformRates).map((platform) => (
                <TabsTrigger
                  key={platform}
                  value={platform}
                  onClick={() => handlePlatformChange(platform)}
                  className="data-[state=active]:shadow-md transition-all"
                >
                  {platform}
                </TabsTrigger>
              ))}
            </TabsList>

            {Object.keys(platformRates).map((platform) => (
              <TabsContent key={platform} value={platform} className="mt-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Select Hours:</span>
                    <span className="text-sm font-medium">
                      {hours} {hours === 1 ? "hour" : "hours"}
                    </span>
                  </div>

                  <Slider
                    defaultValue={[1]}
                    max={6}
                    min={1}
                    step={1}
                    value={[hours]}
                    onValueChange={handleSliderChange}
                    className="my-4"
                  />

                  <div className="flex items-center justify-between">
                    <Input type="number" min="1" max="6" value={hours} onChange={handleHourChange} className="w-24" />
                    <div className="text-xl font-bold">₹{price}</div>
                  </div>

                  <div className="text-sm text-gray-500 mt-2">
                    {platform} rate: ₹{platformRates[platform]}/hour
                  </div>
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>

        <CardFooter>
          <Button
            className="w-full text-lg py-6"
            onClick={handlePayment}
            style={{
              background:
                selectedPlatform === "Netflix" ? "#E50914" : selectedPlatform === "Prime" ? "#00A8E1" : "#0063E5",
            }}
          >
            Pay ₹{price} for {hours} {hours === 1 ? "hour" : "hours"}
          </Button>
        </CardFooter>
      </Card>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Payment</DialogTitle>
            <DialogDescription>
              You are about to purchase {hours} {hours === 1 ? "hour" : "hours"} of {selectedPlatform} access.
            </DialogDescription>
          </DialogHeader>

          <div className="py-4">
            <div className="flex justify-between items-center py-2 border-b">
              <span>Platform</span>
              <span className="font-medium">{selectedPlatform}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b">
              <span>Duration</span>
              <span className="font-medium">
                {hours} {hours === 1 ? "hour" : "hours"}
              </span>
            </div>
            <div className="flex justify-between items-center py-2 border-b">
              <span>Rate</span>
              <span className="font-medium">₹{platformRates[selectedPlatform]}/hour</span>
            </div>
            <div className="flex justify-between items-center py-2 font-bold">
              <span>Total</span>
              <span>₹{price}</span>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              style={{
                background:
                  selectedPlatform === "Netflix" ? "#E50914" : selectedPlatform === "Prime" ? "#00A8E1" : "#0063E5",
              }}
            >
              Proceed to Payment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
